import { getRequestConfig } from 'next-intl/server';
import { notFound } from 'next/navigation';

const locales = ['sr', 'en'];

export default getRequestConfig(async ({ locale }) => {
  if (!locale || !locales.includes(locale as any)) notFound();

  return {
    locale,
    messages: (await import(`../messages/${locale}.json`)).default
  };
});
